TYPES = ("close", "open")
DAYS = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']

EVENT_OPEN = "open"
EVENT_CLOSE="close"